import cv2
import time
import os
import numpy as np

CASCADE_PATH = r"D:\Image_processing\traning_project\mainfile\cascade_lbp\cascade.xml"#填入cascade的路徑
OUTPUT_FILE = "output_detected.avi"
fourcc = cv2.VideoWriter_fourcc(*'XVID')
fps = 20.0

if not os.path.exists(CASCADE_PATH):
    print("❌ 找不到分類器 XML，請確認路徑")
    exit()

classifier = cv2.CascadeClassifier(CASCADE_PATH)
if classifier.empty():
    print("❌ 分類器載入失敗")
    exit()

# === 啟動攝影機 ===
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ 攝影機開啟失敗")
    exit()

frame_size = (int(cap.get(3)), int(cap.get(4)))
out = None
record = False

print("按『r』開始錄影＋偵測，『s』停止錄影，『q』離開")

while True:
    ret, frame = cap.read()
    if not ret:
        print("⚠️ 無法讀取畫面")
        break

    original_frame = frame.copy()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    results = classifier.detectMultiScale(
        gray, scaleFactor=1.05, minNeighbors=2, minSize=(120, 120)
    )

    for (x, y, w, h) in results:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    count = len(results)
    text = f"Detected: {count}"
    font = cv2.FONT_HERSHEY_SIMPLEX
    (tw, th), _ = cv2.getTextSize(text, font, 0.8, 2)
    x_pos = frame.shape[1] - tw - 10
    y_pos = frame.shape[0] - 10
    cv2.rectangle(frame, (x_pos - 5, y_pos - th - 5), (x_pos + tw + 5, y_pos + 5), (255, 0, 0), -1)
    cv2.putText(frame, text, (x_pos, y_pos), font, 0.8, (0, 0, 0), 2)

    display_frame = np.hstack((original_frame, frame))  # 左：原始，右：標記

    cv2.imshow('Original | Detection Result', display_frame)

    if record and out:
        out.write(frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('r') and not record:
        print("🎥 開始錄影＋偵測")
        out = cv2.VideoWriter(OUTPUT_FILE, fourcc, fps, frame_size)
        record = True
    elif key == ord('s') and record:
        print("🛑 停止錄影")
        record = False
        out.release()
        out = None
    elif key == ord('q'):
        print("👋 離開")
        break

# === 清理資源 ===
cap.release()
if out:
    out.release()
cv2.destroyAllWindows()
